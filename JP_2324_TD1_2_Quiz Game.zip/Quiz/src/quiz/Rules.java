package quiz;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Rules extends JFrame implements ActionListener{
    String name,email;
    JButton back,ajt,dbms,wt;
    
    Rules(String name,String email){
        this.name = name;
        this.email=email;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading = new JLabel("welcome "+ name +" to Simple Minds");
        heading.setBounds(50,20,700,30);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD,40));
        heading.setForeground(new Color(30,144,254));
        add(heading);
        
        JLabel rules = new JLabel("Chose your subject");
        rules.setBounds(250,180,300,50);
        rules.setFont(new Font("Tahoms",Font.PLAIN,16));
        add(rules);
        
        wt = new JButton("WT");
        wt.setBounds(250,250,100,30);
        wt.setBackground(new Color(30,144,254));
        wt.setForeground(Color.WHITE);
        wt.addActionListener(this);
        add(wt);
        
        ajt = new JButton("JAVA");
        ajt.setBounds(250,300,100,30);
        ajt.setBackground(new Color(30,144,254));
        ajt.setForeground(Color.WHITE);
        ajt.addActionListener(this);
        add(ajt);
        
        dbms = new JButton("DBMS");
        dbms.setBounds(250,350,100,30);
        dbms.setBackground(new Color(30,144,254));
        dbms.setForeground(Color.WHITE);
        dbms.addActionListener(this);
        add(dbms);
        
        back = new JButton("back");
        back.setBounds(250,400,100,30);
        back.setBackground(new Color(30,144,254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        setSize(800,650);
        setLocation(300,150);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == ajt){
            setVisible(false);
            new Quiz(name,email,"ajt");
        }
        else if(ae.getSource() == dbms){
            setVisible(false);
            new Quiz_dbms(name,email,"dbms");
        }
        else if(ae.getSource() == wt){
            setVisible(false);
            new Quiz_wt(name,email,"wt");
        }
        else{
            setVisible(false);
            new Login();
        }
    }
    
//    public static void main(String[] args){
//        new Rules("User",null);
//    }
 
}
