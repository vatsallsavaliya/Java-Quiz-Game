package quiz;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Quiz extends JFrame implements ActionListener{
    
    String questions[][] = new String[10][5];
    String answer[][] = new String[10][2];
    String useranswers[][] = new String[10][2];
    JLabel qno,question;
    JRadioButton opt1,opt2,opt3,opt4;
    ButtonGroup groupoptions;
    JButton next,submit,lifeline;
    
    public static int timer = 15;
    public static int ans_given = 0;
    public static int count = 0;
    public static int score = 0;
    
    String name,subject,email;
    
    Quiz(String name,String email,String subject){
        this.email = email;
        this.subject = subject;
        this.name = name;
        setBounds(50,0,1440,850);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/Quiz.png"));
        Image i2 = i1.getImage().getScaledInstance(1440,392,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,1440,392);
        add(image);
        
        qno = new JLabel("1");
        qno.setBounds(100, 450, 40, 30);
        qno.setFont(new Font("Tahoma",Font.PLAIN,24));
        add(qno);
        
        question = new JLabel();
        question.setBounds(150, 450, 900, 30);
        question.setFont(new Font("Tahoma",Font.PLAIN,24));
        add(question);
        
        //all question
        questions[0][0]="Which driver translates JDBC calls into ODBC calls and use Windows ODBC built in drivers?";
        questions[0][1]="Type-2";
        questions[0][2]="Type-1";
        questions[0][3]="Type-3";
        questions[0][4]="All of these";
        
        questions[1][0]="Maximum size of data that can be sent using doGet() is?";
        questions[1][1]="1024 bytes";
        questions[1][2]="240 bytes";
        questions[1][3]="128 bytes";
        questions[1][4]="2048 bytes";
        
        questions[2][0]="Which of the following is stored at client side?";
        questions[2][1]="Hidden form fields";
        questions[2][2]="URL rewriting";
        questions[2][3]="Http sessions";
        questions[2][4]="Cookies";
        
        questions[3][0]="A JSP technically gets converted to a _____ during translation time.";
        questions[3][1]="web page";
        questions[3][2]="servlet";
        questions[3][3]="servlet config";
        questions[3][4]="JSP config";
        
        questions[4][0]="______page directive should be used in JSP to generate a PDF.";
        questions[4][1]="contentType";
        questions[4][2]="contentPDF";
        questions[4][3]="TypePDF";
        questions[4][4]="MIMEpdf";
        
        questions[5][0]="request is the instance of ______ class.";
        questions[5][1]="ServletRequest";
        questions[5][2]="HttpRequest";
        questions[5][3]="Request";
        questions[5][4]="GenericRequest";
        
        questions[6][0]="_____ is the powerful query language provided by hibernate.";
        questions[6][1]="HQL";
        questions[6][2]="SQL";
        questions[6][3]="HBQL";
        questions[6][4]="PL/SQL";
        
        questions[7][0]="Which is the first Hibernate object created while developing a hibernate application.";
        questions[7][1]="Session factory";
        questions[7][2]="Configuration";
        questions[7][3]="Session";
        questions[7][4]="Criteria";
        
        questions[8][0]="MVC is composed of which 3 components?";
        questions[8][1]="Model Variable Controller";
        questions[8][2]="Member View Controller";
        questions[8][3]="Model View Control";
        questions[8][4]="Model View Controller";
        
        questions[9][0]="_____cannot be the return type of a request processing method of a controller.";
        questions[9][1]="String";
        questions[9][2]="Void";
        questions[9][3]="Model";
        questions[9][4]="Object";
        
        //all answer
        answer[0][1]="Type-1";
        answer[1][1]="240 bytes";
        answer[2][1]="Cookies";
        answer[3][1]="servlet";
        answer[4][1]="contentType";
        answer[5][1]="HttpRequest";
        answer[6][1]="HQL";
        answer[7][1]="Configuration";
        answer[8][1]="Model View Controller";
        answer[9][1]="Object";
        
        opt1 = new JRadioButton();
        opt1.setBounds(170,520,700,30);
        opt1.setBackground(Color.white);
        opt1.setFont(new Font("Dialig",Font.PLAIN,20));
        add(opt1);
        
        opt2 = new JRadioButton();
        opt2.setBounds(170,560,700,30);
        opt2.setBackground(Color.white);
        opt2.setFont(new Font("Dialig",Font.PLAIN,20));
        add(opt2);
        
        opt3 = new JRadioButton();
        opt3.setBounds(170,600,700,30);
        opt3.setBackground(Color.white);
        opt3.setFont(new Font("Dialig",Font.PLAIN,20));
        add(opt3);
        
        opt4 = new JRadioButton();
        opt4.setBounds(170,640,700,30);
        opt4.setBackground(Color.white);
        opt4.setFont(new Font("Dialig",Font.PLAIN,20));
        add(opt4);
        
        groupoptions = new ButtonGroup();
        groupoptions.add(opt1);
        groupoptions.add(opt2);
        groupoptions.add(opt3);
        groupoptions.add(opt4);
        
        next = new JButton("Next");
        next.setBounds(1100, 550, 200, 40);
        next.setFont(new Font("Tahoma",Font.PLAIN,22));
        next.setBackground(new Color(30,144,255));
        next.setForeground(Color.white);
        next.addActionListener(this);
        add(next);
        
        lifeline = new JButton("50-50 Lifeline");
        lifeline.setBounds(1100, 630, 200, 40);
        lifeline.setFont(new Font("Tahoma",Font.PLAIN,22));
        lifeline.setBackground(new Color(30,144,255));
        lifeline.setForeground(Color.white);
        lifeline.addActionListener(this);
        add(lifeline);
        
        submit = new JButton("submit");
        submit.setBounds(1100, 710, 200, 40);
        submit.setFont(new Font("Tahoma",Font.PLAIN,22));
        submit.setBackground(new Color(30,144,255));
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        submit.setEnabled(false);
        add(submit);
        //ans_given=1;
        start(count);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == next){
            repaint();
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);
            
            ans_given = 1;
            if(groupoptions.getSelection() == null){
                useranswers[count][0] = "";
            }else{
                useranswers[count][0] = groupoptions.getSelection().getActionCommand();
            }
            
            if(count == 8){
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            
            count++;
            start(count);
        }else if(ae.getSource() == lifeline){
            if(count == 2 || count == 4 || count == 6 || count == 8 || count == 9){
                opt2.setEnabled(false);
                opt3.setEnabled(false);
            }else{
                opt1.setEnabled(false);
                opt4.setEnabled(false);
            }
            lifeline.setEnabled(false);
        }else if (ae.getSource() == submit) {
            ans_given = 1;
            if(groupoptions.getSelection() == null){
                useranswers[count][0] = "";
            }else{
                useranswers[count][0] = groupoptions.getSelection().getActionCommand();
            }
            
            for(int i = 0; i < useranswers.length; i++){
                if(useranswers[i][0].equals(answer[i][1])){
                    score += 10;
                }else{
                     score += 0;
                }
            }
            setVisible(false);
            
            try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz_application","root","");
                    String q="update record set score=?,subject=? where email=?;";
                    PreparedStatement pst = con.prepareStatement(q);
                    pst.setInt(1,score );
                    pst.setString(2,subject);
                    pst.setString(3,email);
                    pst.executeUpdate();
                    con.close();
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(Quiz.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            new Score(name,score);
        }
    }
    
    public void paint(Graphics g){
        super.paint(g);
        
        String time = "Time left - " + timer + " seconds";
        g.setColor(Color.RED);
        g.setFont(new Font("Tahoma",Font.BOLD,25));
        
        if(timer > 0){
            g.drawString(time, 1100, 500);
        }else{
            g.drawString("Times up!", 1100, 500);
        }
        
        timer--;
        
        try{
            Thread.sleep(1000);
            repaint();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        if(ans_given == 1){
            ans_given = 0;
            timer = 15;
        }else if (timer < 0){
            timer = 15;
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);
            
            if(count == 8){
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            if(count == 9){
                if(groupoptions.getSelection() == null){
                    useranswers[count][0] = "";
                }else{
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                
                for(int i = 0; i < useranswers.length; i++){
                    if(useranswers[i][0].equals(answer[i][1])){
                        score += 10;
                    }else{
                        score += 0;
                    }
                }
                setVisible(false);
                new Score(name,score);
            }else{
                if(groupoptions.getSelection() == null){
                    useranswers[count][0] = "";
                }else{
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                count++;
                start(count);
            }
        }
    }
    
    public void start(int count){
        qno.setText("" + (count + 1) + ". ");
        question.setText(questions[count][0]);
        opt1.setText(questions[count][1]);
        opt1.setActionCommand(questions[count][1]);
        
        opt2.setText(questions[count][2]);
        opt2.setActionCommand(questions[count][2]);
        
        opt3.setText(questions[count][3]);
        opt3.setActionCommand(questions[count][3]);
        
        opt4.setText(questions[count][4]);
        opt4.setActionCommand(questions[count][4]);
        
        groupoptions.clearSelection();
    }
    
//    public static void main(String[] args){
//        new Quiz("User",null,"ajt");
//    }
}
