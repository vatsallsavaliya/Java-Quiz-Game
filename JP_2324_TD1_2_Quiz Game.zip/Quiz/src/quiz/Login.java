package quiz;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Login extends JFrame implements ActionListener{
    
    JButton next,back;
    JTextField tfname,tmail;
    Login(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/quiz-time.jpg"));
        Image i2 = i1.getImage().getScaledInstance(600,500,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,600,500);
        add(image);
        
        JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(750,60,300,45);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD,40));
        heading.setForeground(new Color(30,144,254));
        add(heading);
        
        JLabel name = new JLabel("Enter your name");
        name.setBounds(810,150,300,20);
        name.setFont(new Font("Mongolian Baiti",Font.BOLD,18));
        name.setForeground(new Color(30,144,254));
        add(name);
        
        tfname = new JTextField();
        tfname.setBounds(735,200,300,25);
        tfname.setFont(new Font("Times New Roman",Font.BOLD,20));
        add(tfname);
        
        JLabel mail = new JLabel("Enter your email");
        mail.setBounds(810,250,300,20);
        mail.setFont(new Font("Mongolian Baiti",Font.BOLD,18));
        mail.setForeground(new Color(30,144,254));
        add(mail);
        
        tmail = new JTextField();
        tmail.setBounds(735,300,300,25);
        tmail.setFont(new Font("Times New Roman",Font.PLAIN,20));
        add(tmail);
        
        next = new JButton("Next");
        next.setBounds(735,350,120,25);
        next.setBackground(new Color(30,144,254));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        add(next);
        
        back = new JButton("back");
        back.setBounds(915,350,144,25);
        back.setBackground(new Color(30,144,254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        setSize(1200,540);
        setLocation(200,150);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == next){
            String name = tfname.getText();
            String email = tmail.getText();
            
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz_application","root","");
                String q="insert into record(email,name) values(?,?);";
                PreparedStatement pst = con.prepareStatement(q);
                pst.setString(1, email);
                pst.setString(2, name);
                pst.execute();
                con.close();
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            setVisible(false);
            new Rules(name,email);
        }
        else if(ae.getSource() == back){
            setVisible(false);
        }
    }
    
    public static void main(String[] args){
        new Login();
    }
}
